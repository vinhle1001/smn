package com.vinhle.searchablespinner;

/**
 * Created by VinhLe on 5/9/2017.
 */

public interface ItemSearchableSelected {

    void OnItemSelected(BaseSearchableModel model) throws Exception;

}
