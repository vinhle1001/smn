package org.eclipse.paho.android.sample.components;


interface ITextSelectCallback {
    void onTextUpdate(String updatedText);
}
